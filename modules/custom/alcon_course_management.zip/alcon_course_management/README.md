About:
=====================================================================================================

Myalcon Course Management module is use to import the configuration of all the below items (Drupal items) to create Course listing page with all the required functionality. Also this module is use to alter the template for views item and custom functionality related to Course management.

Here are the items:
  -- Create Course Page content type with fields.
  -- Create Course Category taxonomy with fields and Term items.
  -- Create Image style for both the Teaser Images.
  -- Create Responsive Image style for Course page..
  -- Create View for Course category tab, Course Catalog listing..
  -- Block configuration for all Views.


Note:
=====================================================================================================

All the sitestudio stuff related to Course Management will import in a site as per sitestudio standard Package export/import methopdology. All the Packages will be available in sitestudioreference ACSF Prod site in manage package section. List of items are in below:

Custom Styles:
=====================================================================================================
  -- Course Catalog Lists (coh-style-course-catalog-lists).
  -- Course Category Filter Tab (coh-style-course-category-filter-tab).
  -- Course Page (coh-style-course-page).

Content Template:
=====================================================================================================
  -- Course page >> Course Page (Full content).

