/**
 * @file
 * Custom JavaScript functionality.
 */
(function($, Drupal) {
  Drupal.behaviors.Course = {
    attach: function (context, settings) {

      // Count in BEF list.
      var linum = $(".bef-exposed-form ul li").length;
      if (linum > 6) {
        $(".bef-exposed-form ul").addClass('better-exposed-filter-large');
      }

      // Count in Cat list.
      var catlinum = $(".coh-style-course-category-filter-tab ul.course-cat-items li").length;
      if (catlinum > 6) {
        $(".coh-style-course-category-filter-tab ul.course-cat-items").addClass('better-exposed-filter-large');
      }

      // Trigger click event as per Category item.
      $(".coh-style-course-category-filter-tab ul.course-cat-items li a").click(function() {
        var index = $(this).parent().index();

        // Add active/selected class.
        $(".coh-style-course-category-filter-tab ul.course-cat-items li a").removeClass("selected");
        $(".coh-style-course-category-filter-tab ul.course-cat-items li").removeAttr("id");
        $(this).addClass("selected");
        $(this).parent().attr('id', "selecteditem");

        // Get the text of selected li.
        var menuText = $(this).text();

        // Check for First LI element.
        if (index == 0) {
          $('#views-exposed-form-course-management-calalog-course-catalog .bef-links ul > li:first a').trigger('click');
        }
        else {
          // Trigger click event as per selected menu item.
          $("#views-exposed-form-course-management-calalog-course-catalog ul li a").each(function(){
            var exposedMenuText = $(this).text();
            if (exposedMenuText === menuText) {
              $(this).trigger("click");
            }
          });
        }
      });

      // Course Management Tab Sub-title text.
      if ($("body").find('.all-tab-sub-title').length == 1) {
        $('#block-views-block-course-management-calalog header .course-subtitle').addClass('course-display-none');
        if ($('.all-tab-sub-title').hasClass('course-display-none')) {
          $('.all-tab-sub-title').removeClass('course-display-none');
        }
      }

      // Only scroll if item on the tab menu course-cat-items is clicked.
      let scrollTab = false;
      let catItems = document.querySelectorAll(".course-cat-items li");
      catItems.forEach(function(catItem) {
        catItem.addEventListener("click", function() {
          scrollTab = true;
        });
      });

      // Ajax complete functionality.
      $(document).ajaxComplete(function(ev) {
        // Slide to viewport.
        if (scrollTab) {
          const clicking_item = document.getElementById('selecteditem');
          if (clicking_item) {
            clicking_item.scrollIntoView({behavior: "smooth", block: "nearest", inline: "nearest"});
          }
        }
        scrollTab = false;

        // Count in BEF list.
        var linum = $(".bef-exposed-form ul li").length;
        if (linum > 6) {
          $(".bef-exposed-form ul").addClass('better-exposed-filter-large');
        }

        // Count in Cat list.
        var catlinum = $(".coh-style-course-category-filter-tab ul.course-cat-items li").length;
        if (catlinum > 6) {
          $(".coh-style-course-category-filter-tab ul.course-cat-items").addClass('better-exposed-filter-large');
        }

        // Course Management Tab Sub-title text.
        if ($("body").find('.all-tab-sub-title').length == 1) {
          if ($('#views-exposed-form-course-management-calalog-course-catalog .bef-links ul > li:first a').hasClass('bef-link--selected')) {
            $('#block-views-block-course-management-calalog header .course-subtitle').addClass('course-display-none');
            $('.all-tab-sub-title').removeClass('course-display-none');
          }
          else {
            $('#block-views-block-course-management-calalog header .course-subtitle').removeClass('course-display-none');
            $('.all-tab-sub-title').addClass('course-display-none');
          }
        }
      });
    }
  };
}(jQuery, Drupal));
