<?php

namespace Drupal\alcon_course_management;

use Drupal\Core\Extension\ModuleUninstallValidatorInterface;
use Drupal\Core\StringTranslation\StringTranslationTrait;
use Drupal\Core\StringTranslation\TranslationInterface;

/**
 * Prevents blog module from being uninstalled whilst any blog nodes exist.
 */
class CourseUninstallValidator implements ModuleUninstallValidatorInterface {

  use StringTranslationTrait;

  /**
   * Constructs a new validator.
   *
   * @param \Drupal\Core\StringTranslation\TranslationInterface $string_translation
   *   The string translation service.
   */
  public function __construct(TranslationInterface $string_translation) {
    $this->setStringTranslation($string_translation);
  }

  /**
   * {@inheritdoc}
   */
  public function validate($module) {
    $reasons = [];
    if ($module === 'alcon_course_management' && alcon_course_management_node_counter() != 0) {
      $reasons[] = $this->t('To uninstall Alcon Course Management module, first delete all <em>Course Page</em> content.');
    }
    return $reasons;
  }

}
