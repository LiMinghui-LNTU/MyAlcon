CONTENTS OF THIS FILE
---------------------

 * Introduction
 * Requirements
 * Installation


INTRODUCTION
------------
This module provide features to Make website users blocked that are blocked or non-existent in ACSF user management console. ACSF blocked users fetch through API.


REQUIREMENTS
------------
This module requires no modules outside of Drupal core.


INSTALLATION
------------

2) Enable the module using Manage -> Extend (/admin/modules).


A NOTE ABOUT THIS
--------------------
This module have feature to block website users using drush command

1) To block website users run drush command acsfuser:block